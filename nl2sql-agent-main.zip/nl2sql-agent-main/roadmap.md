# Roadmap

- Rewrite user's query.
- Add caching with Redis
- Automatic cleanup of state
