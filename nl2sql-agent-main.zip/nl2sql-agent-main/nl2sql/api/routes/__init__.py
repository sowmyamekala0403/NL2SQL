"""API routes for the NL2SQL application."""
