"""Agent implementation for the NL2SQL agent."""
