"""This module contains the tools for the chat agent."""
