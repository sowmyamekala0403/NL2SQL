"""Database connectors."""

from nl2sql.database.postgresql import PostgreSQLConnector

__all__ = ["PostgreSQLConnector"]
